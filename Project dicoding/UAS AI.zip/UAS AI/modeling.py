# Mengimpor library yang dibutuhkan
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report
from sklearn.tree import DecisionTreeClassifier
from sklearn.tree import plot_tree

# Membaca dataset dari file CSV dengan pembatas kolom ';'
dataset = pd.read_csv("datadiabetes.csv", sep=';')

# Menerapkan label encoding pada kolom tertentu
enc = LabelEncoder()
dataset['Glukosa'] = enc.fit_transform(dataset['Glukosa'].values)
dataset['BloodPressure'] = enc.fit_transform(dataset['BloodPressure'].values)
dataset['BMI'] = enc.fit_transform(dataset['BMI'].values)
dataset['Age'] = enc.fit_transform(dataset['Age'].values)
dataset['Diabetes'] = enc.fit_transform(dataset['Diabetes'].values)

# Memisahkan atribut (features) dan target variable
atr_dataset = dataset.drop(columns='Diabetes')
cls_dataset = dataset['Diabetes']

# Membagi dataset menjadi data latih dan data uji
X_train, X_test, y_train, y_test = train_test_split(atr_dataset, cls_dataset, test_size=0.2, random_state=42)

# Membuat model Decision Tree
dtree = DecisionTreeClassifier()

# Melatih model dengan data latih
dtree.fit(X_train, y_train)

# Melakukan prediksi menggunakan data uji
y_pred = dtree.predict(X_test)

# Menghitung metrik evaluasi
accuracy = accuracy_score(y_test, y_pred)
confusion_mat = confusion_matrix(y_test, y_pred)
classification_rep = classification_report(y_test, y_pred)

# Menampilkan hasil evaluasi
print(f"Akurasi: {accuracy}")
print(f"Confusion Matrix:\n{confusion_mat}")
print(f"Classification Report:\n{classification_rep}")

# Menampilkan visualisasi pohon keputusan
plt.figure(figsize=(12, 9))
plot_tree(dtree, feature_names=atr_dataset.columns, class_names=['Tidak', 'Ya'], filled=True, rounded=True)
plt.show()
